import React, { useEffect, useState } from 'react'
import img from "../Images/home.svg"
export const Home = () => {
    
    const [topbutton,settopbutton]=useState(false);
    useEffect(()=>{
        window.addEventListener("scroll",()=>{
            if(window.scrollY > 100){
                settopbutton(true);
            }
            else{
                settopbutton(false);
            }
        })
    },[])
const scrollUp=()=>{
window.scrollTo({
    top:0,behavior:"smooth"
})
}
  return (
    <>
   {
    topbutton &&( <button className='fadeinout' style={{
        position:"fixed",
        bottom:"100px",
        right:"50px",
        height:"50px",
        width:"50px",
        fontSize:"50px",
        zIndex:"1",
        border:"1px solid",
       borderRadius:"50px",
      
       background:"radial-gradient(circle, rgba(238,174,202,1) 0%, rgba(148,187,233,1) 100%)"
    }} onClick={()=>scrollUp()}>^</button>)
   }
    <div className='container-fluid'>
<div className='row'>
<div className='col-md-12'>
<nav className="navbar navbar-expand-sm navbar-light" style={{background:"white",minWidth:"100%" ,background:"#F2F2F2"}}>
  <a className="navbar-brand" href="#" style={{color:"#6C63FF",textShadow:"10px,red", fontSize:"20px",fontWeight:"bolder" }}>Sagar</a>
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#colapsid" aria-controls="colapsid" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>

  <div className="collapse navbar-collapse justify-content-center" id="colapsid" >
   
    <div className='navbar-nav nav-item mr-auto'><a href='#sectionHome'  className='nav-link'style={{color:"#6C63FF",fontSize:"20px",fontWeight:"bolder"}}>Home</a></div>
    <div className='navbar-nav nav-item mr-auto'><a href='#sectionAbout'  className='nav-link'style={{color:"#6C63FF",fontSize:"20px",fontWeight:"bolder"}}>About</a></div>
    <div className='navbar-nav nav-item mr-auto'><a href='#sectionContactUs'  className='nav-link'style={{color:"#6C63FF",fontSize:"20px",fontWeight:"bolder"}}>Contact</a></div>
    {/* <div className='navbar-nav nav-item mr-auto'><Link to="#sectionHome" className='nav-link'style={{color:"#6C63FF",fontSize:"20px",fontWeight:"bolder"}}>Home</Link></div> */}
    {/* <div className='navbar-nav nav-item mr-auto'><Link to="#sectionAbout" className='nav-link'style={{color:"#6C63FF",fontSize:"20px",fontWeight:"bolder"}}>About</Link></div> */}
    {/* <div className='navbar-nav nav-item mr-auto'><Link to="#sectionContact" className='nav-link'style={{color:"#6C63FF",fontSize:"20px",fontWeight:"bolder"}}>Contact</Link></div> */}
    {/* <div className='navbar-nav nav-item mr-auto'><Link to="/Contacts" className='nav-link'style={{color:"#6C63FF",fontSize:"20px",fontWeight:"bolder"}}>Contact</Link></div> */}
   
  </div>
</nav>
</div>
</div>
</div>
<div className='col-md-12' style={{textAlign:"center",background:"radial-gradient(circle, rgba(238,174,202,1) 0%, rgba(148,187,233,1) 100%)"}}>

    <div id="sectionHome" style={{height:"100vh"}}>
<div>Home</div>
    </div>

    <div id="sectionAbout"style={{height:"100vh"}}>
    <div className='row'>
  <div className='col-md-6 mt-5'>
      <h1 style={{color:"white"}}><span style={{color:"rgb(108, 99, 255)",fontSize:"50px"}}>Hey!</span>I Am Sagar</h1>
       <div className='row'>
        <div className='col-md-10' style={{alignItems:"center"}}>
  <h1>Portfolio Links</h1>
  <div className='' style={{color:"#FFB6B6" ,fontSize:"50px"}}>
     <a href='#'>
    <i className="fa fa-github-square  socialLinks m-2" ></i></a>
    <a href='#'>
 <i className="fa fa-facebook-square socialLinks m-2"></i></a>
 <a href='#'>
  <i className="fa fa-linkedin-square socialLinks m-2"></i></a>
  </div>
</div>
</div>
  </div>
  <div className='col-md-6'>
    <img src={img} style={{Height:"500px",marginTop:"50px",boxSizing:"border-box" ,maxWidth:"500px"}}/>
    </div>
</div>
    </div>
    <div id="sectionContactUs"style={{height:"100vh"}}>
    <div className='row'>
       
       <div className="col-md-4" style={{marginTop:"20px",textAlign:"center"}}>
         <div className='card'style={{height:"200px"}}>
           <div className='card-heading'><h2>Project No:1</h2></div>
           <div className='card-body'>
           <div className='row'>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
</div>
           </div>
           </div >
       </div>

       <div className="col-md-4"  style={{marginTop:"20px" ,textAlign:"center"}}>
         <div className='card'style={{height:"200px"}}>
           <div className='card-heading'><h2>Project No:2</h2></div>
           <div className='card-body'>
           <div className='row'>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
</div>
           </div>
           </div >
       </div>

       <div className="col-md-4"  style={{marginTop:"20px" ,textAlign:"center"}}>
         <div className='card'style={{height:"200px"}}>
           <div className='card-heading'><h2>Project No:3</h2></div>
           <div className='card-body'>
           <div className='row'>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
</div>
           </div>
           </div >
       </div>
     </div>
   

    </div>
    </div>
    </>
  )
}
