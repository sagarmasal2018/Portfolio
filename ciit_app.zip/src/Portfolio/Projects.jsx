import React from 'react'
import img from "../Images/home.svg"
export const Projects = () => {
  return (
    <>
    
      <div className='row'>
       
        <div className="col-md-4" style={{marginTop:"20px",textAlign:"center"}}>
          <div className='card'style={{height:"200px"}}>
            <div className='card-heading'><h2>Project No:1</h2></div>
            <div className='card-body'>
            <div className='row'>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
</div>
            </div>
            </div >
        </div>

        <div className="col-md-4"  style={{marginTop:"20px" ,textAlign:"center"}}>
          <div className='card'style={{height:"200px"}}>
            <div className='card-heading'><h2>Project No:2</h2></div>
            <div className='card-body'>
            <div className='row'>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
</div>
            </div>
            </div >
        </div>

        <div className="col-md-4"  style={{marginTop:"20px" ,textAlign:"center"}}>
          <div className='card'style={{height:"200px"}}>
            <div className='card-heading'><h2>Project No:3</h2></div>
            <div className='card-body'>
            <div className='row'>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
<div className='col-md-3'><img src={img} style={{height:"40px",width:"100%"}}/></div>
</div>
            </div>
            </div >
        </div>
      </div>
    

    </>
  )
}
