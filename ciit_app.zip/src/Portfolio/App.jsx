import React from "react";
import {BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Portfolio from "./Portfolio";
import { Layout } from "./Layout";
import { Projects } from "./Projects";
import { ContactUs } from "./ContactUs";

function App() {
  return (
    <>
      <div>
        <Router>

<Routes>
  <Route path="/" element={<Layout/>}>
  <Route path="Project" element={<Projects/>}/>
  <Route path="Portfolio" element={<Portfolio/>}/>
  <Route path="Contacts" element={<ContactUs/>}/>
  </Route>
</Routes>

        </Router>
      </div>
    
    </>
  );
}

export default App;
