import React from 'react'
import img from "../Images/home.svg"
 const Portfolio = () => {
  return (
    <>
<div className='row'>
  <div className='col-md-6 mt-5'>
      <h1 style={{color:"white"}}><span style={{color:"rgb(108, 99, 255)",fontSize:"50px"}}>Hey!</span>I Am Sagar</h1>
       <div className='row'>
        <div className='col-md-10' style={{alignItems:"center"}}>
  <h1>Portfolio Links</h1>
  <div className='' style={{color:"#FFB6B6" ,fontSize:"50px"}}>
     <a href='#'>
    <i className="fa fa-github-square  socialLinks m-2" ></i></a>
    <a href='#'>
 <i className="fa fa-facebook-square socialLinks m-2"></i></a>
 <a href='#'>
  <i className="fa fa-linkedin-square socialLinks m-2"></i></a>
  </div>
</div>
</div>
  </div>
  <div className='col-md-6'>
    <img src={img} style={{Height:"500px",marginTop:"50px",boxSizing:"border-box" ,maxWidth:"500px"}}/>
    </div>
</div>
    
    </>
  )
}
export default Portfolio;