import React from 'react'
import{Link,Outlet} from "react-router-dom"
export const Layout = () => {
  return (
    <>
      <div className='container-fluid'>
    <div className='row'>
      <div className='col-md-12'>
<nav className="navbar navbar-expand-sm navbar-light fixed-top" style={{background:"white",minWidth:"100%" ,background:"#F2F2F2"}}>
  <a className="navbar-brand" href="#" style={{color:"#6C63FF",textShadow:"10px,red", fontSize:"20px",fontWeight:"bolder" }}>Sagar</a>
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#colapsid" aria-controls="colapsid" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>

  <div className="collapse navbar-collapse justify-content-center" id="colapsid" >
   
    <div className='navbar-nav nav-item mr-auto'><Link to="/" className='nav-link'style={{color:"#6C63FF",fontSize:"20px",fontWeight:"bolder"}}>Home</Link></div>
    <div className='navbar-nav nav-item mr-auto'><Link to="/Project" className='nav-link'style={{color:"#6C63FF",fontSize:"20px",fontWeight:"bolder"}}>projects</Link></div>
    <div className='navbar-nav nav-item mr-auto'><Link to="/Portfolio" className='nav-link'style={{color:"#6C63FF",fontSize:"20px",fontWeight:"bolder"}}>Portfolio</Link></div>
    <div className='navbar-nav nav-item mr-auto'><Link to="/Contacts" className='nav-link'style={{color:"#6C63FF",fontSize:"20px",fontWeight:"bolder"}}>Contact</Link></div>
    
  </div>
</nav>
</div>

<div className='col-md-12' style={{marginTop:"50px",height:"calc(100vh - 50px)",background:"radial-gradient(circle, rgba(238,174,202,1) 0%, rgba(148,187,233,1) 100%)"}}>
<Outlet />

</div> 
      

       </div>
       </div>
    </>
  )
}
